<?php 
$theme_name = "Garud";
$theme_author = "Vivek Nayak";