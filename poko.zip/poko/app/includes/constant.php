<?php 
define('T_ZON_SEC', 'zon_section');
define('T_ZON_CONFIG', 'zon_config');
define('T_ZON_GAMES', 'zon_games');
define('T_ZON_CATEGORY', 'zon_category');
define('T_ZON_F_GAMES', 'zon_featured_games');
define('T_ZON_BLOGS', 'zon_blog');
define('T_ZON_ADS', 'zon_ads');
define('T_ZON_PAGES', 'zon_pages');
define('T_ZON_COMMENTS', 'zon_comments');
define('T_ZON_USERS', 'zon_users');
define('T_ZON_LIKES', 'zon_likes');
define('T_ZON_REPORTS', 'zon_report');
define("T_ZON_DISLIKES", "zon_unlikes");